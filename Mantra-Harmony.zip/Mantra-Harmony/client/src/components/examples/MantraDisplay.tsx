import MantraDisplay from '../MantraDisplay';

export default function MantraDisplayExample() {
  const mockMantra = {
    nombre: "Om Mani Padme Hum",
    texto: "Om Mani Padme Hum",
    significado: "La joya en el loto. Purifica las seis imperfecciones.",
    deidad: "Avalokiteshvara"
  };
  
  return (
    <MantraDisplay
      mantra={mockMantra}
      categoryColor="from-rose-100 to-pink-100"
      isPlaying={false}
      repetitions={5}
    />
  );
}
