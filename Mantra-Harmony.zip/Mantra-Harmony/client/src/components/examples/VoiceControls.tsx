import { useState } from 'react';
import VoiceControls from '../VoiceControls';

export default function VoiceControlsExample() {
  const [speed, setSpeed] = useState(0.9);
  const [pitch, setPitch] = useState(1.0);
  const [volume, setVolume] = useState(0.8);
  const [culture, setCulture] = useState('hi-IN');
  
  return (
    <VoiceControls
      speed={speed}
      pitch={pitch}
      volume={volume}
      selectedCulture={culture}
      voices={[]}
      selectedVoice={null}
      onSpeedChange={setSpeed}
      onPitchChange={setPitch}
      onVolumeChange={setVolume}
      onCultureChange={setCulture}
      onVoiceChange={() => {}}
    />
  );
}
