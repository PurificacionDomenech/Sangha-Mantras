import { useState } from 'react';
import MantraCard from '../MantraCard';

export default function MantraCardExample() {
  const [selected, setSelected] = useState(0);
  
  const mockMantras = [
    {
      nombre: "Om Mani Padme Hum",
      texto: "Om Mani Padme Hum",
      significado: "La joya en el loto. Purifica las seis imperfecciones y desarrolla compasión infinita.",
      deidad: "Avalokiteshvara"
    },
    {
      nombre: "Mantra de Chenrezig",
      texto: "Om Mani Peme Hung",
      significado: "Variante tibetana. Invoca la compasión del Bodhisattva de la misericordia.",
      deidad: "Chenrezig"
    }
  ];
  
  return (
    <div className="space-y-3">
      {mockMantras.map((mantra, idx) => (
        <MantraCard
          key={idx}
          mantra={mantra}
          isSelected={selected === idx}
          categoryColor="from-rose-100 to-pink-100"
          onClick={() => setSelected(idx)}
          index={idx}
        />
      ))}
    </div>
  );
}
