import AmbientSounds from '../AmbientSounds';

export default function AmbientSoundsExample() {
  return <AmbientSounds isSessionActive={false} />;
}
