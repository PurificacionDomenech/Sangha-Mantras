import InstructionsPanel from '../InstructionsPanel';

export default function InstructionsPanelExample() {
  return <InstructionsPanel />;
}
