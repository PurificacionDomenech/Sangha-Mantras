import { useState } from 'react';
import CategorySelector from '../CategorySelector';

export default function CategorySelectorExample() {
  const [selected, setSelected] = useState('compasion');
  
  return (
    <CategorySelector 
      selectedCategory={selected} 
      onSelectCategory={setSelected}
    />
  );
}
