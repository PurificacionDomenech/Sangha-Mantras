import { useState } from 'react';
import TimerControls from '../TimerControls';

export default function TimerControlsExample() {
  const [duration, setDuration] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  
  return (
    <TimerControls
      durationMinutes={duration}
      timeRemaining={isPlaying ? 540 : 0}
      isPlaying={isPlaying}
      onDurationChange={setDuration}
      onToggleSession={() => setIsPlaying(!isPlaying)}
      onPlayOnce={() => console.log('Play once')}
      sessionFinished={false}
    />
  );
}
